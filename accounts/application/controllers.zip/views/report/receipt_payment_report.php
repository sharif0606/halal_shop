<style>
	
</style>
<div class="col-xs-12">
	<div class="clearfix">
		<div class="tableTools-container">
		<button class="dt-button buttons-collection buttons-colvis btn btn-white btn-primary btn-bold" onclick="printPageArea('display')"><i class="fa fa-print bigger-110 grey"></i> <span class="hidden">Print</span></button>
		</div>
	</div>
	<div class="table-header">
		প্রাপ্তি ও প্রদান হিসাব
	</div>
	<!-- div.table-responsive -->
	<!-- div.dataTables_borderWrap -->
		<div id="display">
					<h4 class="vHide">Probati Somobay Somity Ltd</h4>
					<p class="vHide">Probati Laborer Co-Operative Organization</p>
					<p class="vHide">Jaker Tower(4th floor),Upzila Sadar, Boalkhali,Chittagong, Reg #12967, Established:2018</p>
					<p class="text-center vHide">প্রাপ্তি ও প্রদান হিসাব</p>
			<table id="" class="table table-striped table-bordered table-hover" width="100%">
				<thead>
					<tr>
						<th>জমা</th>
						<th>চলতি মাসের</th>
						<th>চলতি বছরের</th>
						<th>খরচ</th>
						<th>চলতি মাসের</th>
						<th>চলতি বছরের</th>
					</tr>
				</thead>				
				<tbody>
					<tr>
						<td>নগদ</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ব্যাংক কিস্তি</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>ঋণ হিসাব আসল</strong></td>
						<td></td>
						<td></td>
						<td><strong>ঋণ বিতরণ আসল</strong></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ক্ষুদ্র  ঋণ মহিলা</td>
						<td></td>
						<td></td>
						<td>ক্ষুদ্র  ঋণ মহিলা</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ক্ষুদ্র  উদ্যোগী ঋণ পুরুষ</td>
						<td></td>
						<td></td>
						<td>ক্ষুদ্র  উদ্যোগী ঋণ পুরুষ</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>এল. টি. এস. আদায়</td>
						<td></td>
						<td></td>
						<td>এল. টি. এস. ফেরত</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ঝুকি তহবিল গ্রহন</td>
						<td></td>
						<td></td>
						<td>ঝুকি তহবিল প্রদান</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>প্রভাতি বিশেষ তহবিল</td>
						<td></td>
						<td></td>
						<td>প্রভাতি বিশেষ তহবিল</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
					<tr>
						<td>শেয়ার আমানাত আদায়</td>
						<td></td>
						<td></td>
						<td>শেয়ার আমানাত ফেরত</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>সল্প মেয়াদী অগ্রিম</td>
						<td></td>
						<td></td>
						<td>সল্প মেয়াদী অগ্রিম</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>বিশেষ ঋণ</td>
						<td></td>
						<td></td>
						<td>বিশেষ ঋণ</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>মোটর সাইকেল অগ্রিম</td>
						<td></td>
						<td></td>
						<td>মোটর সাইকেল অগ্রিম</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>বাই সাইকেল অগ্রিম</td>
						<td></td>
						<td></td>
						<td>বাই সাইকেল অগ্রিম</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>প্রভিডেন্ট ফান্ড</td>
						<td></td>
						<td></td>
						<td>প্রভিডেন্ট ফান্ড</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>মেডিকেল ফান্ড</td>
						<td></td>
						<td></td>
						<td>মেডিকেল ফান্ড</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>গ্রাচুইটি  ফান্ড</td>
						<td></td>
						<td></td>
						<td>গ্রাচুইটি  ফান্ড</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td><strong>বেতন হিসাব</strong></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td>এরিয়া  ম্যানেজার</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>সার্ভিস চার্জ আয়</strong></td>
						<td></td>
						<td></td>
						<td>শাখা হিসাব রক্ষক</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>গ্রামীন ক্ষুদ্র ঋণ মহিলা</td>
						<td></td>
						<td></td>
						<td> কার্যক্রম সংগঠক</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ক্ষুদ্র  উদ্যোগী ঋণ পুরুষ</td>
						<td></td>
						<td></td>
						<td>অফিস পিয়ন</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ব্যাংক হতে লাভ প্রদান</td>
						<td></td>
						<td></td>
						<td>অফিস ভাড়া</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>পাস বই বিক্রি</td>
						<td></td>
						<td></td>
						<td>মোবাইল ভাতা</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ভর্তি ফি আদায়</td>
						<td></td>
						<td></td>
						<td>যাতায়াত ভাতা</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>ঋণ ফরম ফি</td>
						<td></td>
						<td></td>
						<td>বিদ্যুৎ বিল</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>আবাসন আয়</td>
						<td></td>
						<td></td>
						<td>আপ্যায়ন বিল</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>রাইট অফ আদায়</td>
						<td></td>
						<td></td>
						<td>ষ্টেশনারী বিল</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td>ফটোকপি বিল</td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
						<td><strong>উপমোট</strong></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
				<tfoot>
				<tr>
					<td>ম্যানেজার সাক্ষর</td>
					<td colspan="3"></td>
					<td>তারিখ এবং সময়</td>
					<td colspan="3"><?php $date = date('m/d/Y h:i:s a', time()); echo $date;?></td>
				</tr>
				</tfoot>
			</table>
		</div>
	</div>
</div>
<script type="text/javascript">
//print all report
	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;border-collapse: collapse;} table, td, th {border: 1px solid black;} table>thead>tr{border:none;} h4,p{text-align:center;padding:0;margin:0}</style>');
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>
