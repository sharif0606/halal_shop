<?php if($this->session->flashdata('message')): ?>
	<?php echo $this->session->flashdata('message'); ?>
<?php endif;?> 
			<div class="dashboard">
			<div class="dashboard-overlay"></div>
	
			<div class="row">
				<div class="col-xs-12">
					<!-- PAGE CONTENT BEGINS -->
					
					

					<div class="hr hr32 hr-dotted"></div>
					<!-- PAGE CONTENT ENDS -->
				</div><!-- /.col -->
			</div><!-- /.row -->
</div>
