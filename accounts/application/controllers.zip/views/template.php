<?php $this->load->view('include/header') ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
					<?php $this->load->view($page) ?>
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
<?php $this->load->view('include/footer') ?>